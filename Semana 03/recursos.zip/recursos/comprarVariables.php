<?php

$a = 5;
$b = 8;

echo ($b < $a); // Imprime 'false', ya que $b no es menor que $a

?>

<?php

$numero = "42";

if (is_int($numero)) {
    echo "La variable es un número entero.";
} else {
    echo "La variable no es un número entero.";
}

?>
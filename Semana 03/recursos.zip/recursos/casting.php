<?php 
    $velocidad = 501.789; // float
	$nueva_velocidad = (integer)$velocidad; // se convierte a integer
?>

<?php
// Buenas prácticas: Nombres descriptivos y en minúsculas
// ser constante con la mayusculas y minusculas.
$nombreCompleto = 'Pepe Pérez';
$edadPersona = 25;
$correoElectronico = 'pepe@example.com';


// Malas prácticas: Nombres cortos y poco descriptivos
$a = 'Juan Pérez';
$b = 25;
$c = 'juan@example.com';


$fechaISO = '2023-01-23';

echo $nombreCompleto;


?>
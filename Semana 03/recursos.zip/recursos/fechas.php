<?php
	$hoy = getdate();
	print_r($hoy);	

    //Ouput:

/*Array
(
    [seconds] => 21
    [minutes] => 58
    [hours] => 2
    [mday] => 24
    [wday] => 3
    [mon] => 1
    [year] => 2024
    [yday] => 23
    [weekday] => Wednesday
    [month] => January
    [0] => 1706065101
)*/

echo date("d-m-Y");	



?>
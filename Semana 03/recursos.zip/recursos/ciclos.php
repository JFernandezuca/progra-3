<?php
$contador = 10;

// El bucle se ejecutará mientras $contador sea mayor que 0
while ($contador > 0) {
    // Imprime el valor actual de $contador y añade un salto de línea
    echo $contador . "<br>";

    // Decrementa el valor de $contador en 1 en cada iteración
    $contador--;
}
?>


<?php
for ($i = 1; $i <= 10; $i++) {
    echo $i . "<br>";
}
?>


<?php

// Concatenación de cadenas
$nombre = "Juan";

echo "Nombre: " . $nombre_completo . "<br>";

// Concatenación en la impresión de texto
$edad = 30;
echo "El usuario " . $nombre . " tiene " . $edad . " años.<br>";


// Concatenación en la salida HTML
$enlace = "<a href='https://www.ejemplo.com'>Enlace de Ejemplo</a>";
echo "Visita nuestro sitio: " . $enlace . "<br>";

// Concatenación de valores numéricos
$num1 = 10;
$num2 = 20;
$suma = $num1 + $num2;

echo "La suma de $num1 y $num2 es: " . $suma . "<br>";

echo 'Hoy es '.date('d/m/Y');
?>

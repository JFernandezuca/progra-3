<?php

$precio = 100;
$tamaño = 18;

// La expresión lógica se evalúa como false porque $tamaño no es menor que 18
echo ($precio > 50 && $tamaño < 18); // Output: false


?>